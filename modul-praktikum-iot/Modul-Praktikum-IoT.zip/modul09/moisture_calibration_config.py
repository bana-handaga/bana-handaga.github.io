# This file was automatically created by moisture_ads1115_calibrate.py
# Number of samples: 100
# Voltage range is 0.7003
MIN_VOLTS = 0.0038
MAX_VOLTS = 0.7042
