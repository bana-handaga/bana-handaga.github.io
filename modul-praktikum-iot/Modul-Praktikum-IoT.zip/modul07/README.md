# Practical Python Programming for IoT

## Chapter 7 - Turning Things On and Off

* `requirements.txt` - Python dependencies required for this chapter

* `optocoupler_test` - Using a Optocoupler as a switch

* `transistor_test` - Using a MOSFET as a switch

